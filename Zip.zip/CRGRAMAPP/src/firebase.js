01.03 19:40
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyAEC5efoUlPhwgJvd_Xh7ORi-xLswXsJT8",
  authDomain: "crgramapp.firebaseapp.com",
  projectId: "crgramapp",
  storageBucket: "crgramapp.firebasestorage.app",
  messagingSenderId: "634574700416",
  appId: "1:634574700416:web:58f2326001effe36804b65"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);

