01.03 19:42
App.js
import React from 'react';
import './App.css';

function App() {
  return (
    <div className="app">
      <div className="header">CRGRAM</div>
      <div className="feed">Postlar shu yerda chiqadi...</div>
      <nav className="navbar">
        <button></button>
        <button></button>
        <button className="plus">+</button>
        <button>▶️</button>
        <button></button>
      </nav>
    </div>
  );
}
export default App;

